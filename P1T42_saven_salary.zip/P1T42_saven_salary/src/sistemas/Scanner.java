package sistemas;

public class Scanner {
}
